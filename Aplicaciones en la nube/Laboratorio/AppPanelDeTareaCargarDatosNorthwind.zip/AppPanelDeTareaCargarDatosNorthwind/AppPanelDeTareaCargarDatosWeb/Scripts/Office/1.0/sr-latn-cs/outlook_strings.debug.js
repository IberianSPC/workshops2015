﻿
Type.registerNamespace("_u");
_u.ExtensibilityStrings = function()
{
};
_u.ExtensibilityStrings.registerClass("_u.ExtensibilityStrings");
_u.ExtensibilityStrings.l_EwsRequestOversized_Text = "_Ţhę řęqűëšţ ěxçëęďś ťhé 1 MB şîźě łîmîť. Pľéąşé mőđífý ýőűř EWS řëqüęşţ.džšćđČdžšćđČ_";
_u.ExtensibilityStrings.l_OffsetNotfound_Text = "_Ăň óffšęť fôř ťhíš ťímé śţámp čóűłđń'ť bé fôµňđ.džšćđČdž_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text = "_Ëľęváťéđ pěŕmîšśîőń íş řěqµíŕęđ ťó ćáľĺ ţhë měťhôđ: '{0}'.džšćđČdžš_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text = "_Ęľëváţëđ pěŕmîśşîôń îš řěqüířęď ţó ăćçęşš přóţęćţëď měmběŕš ôf ţhě JävăŚçŕípť API fôř Ôffîçě.džšćđČdžšćđČdžš_";
_u.ExtensibilityStrings.l_InvalidEventDates_Text = "_Ţhě ëňđ đąţę őćçµřš bëfőŕé ťhé šţáŕţ ďáťë.džšćđČd_";
_u.ExtensibilityStrings.l_InvalidDate_Text = "_Ţhě íńpüţ đőęśň'ţ ŕéśöłvě ťö â văłíď đăťé.džšćđČd_";
_u.ExtensibilityStrings.l_InternalProtocolError_Text = "_Îńţëŕňáĺ přôťôćöľ ěŕřôŕ: '{0}'.džšćđ_"
