﻿
Type.registerNamespace("_u");
_u.ExtensibilityStrings = function()
{
};
_u.ExtensibilityStrings.registerClass("_u.ExtensibilityStrings");
_u.ExtensibilityStrings.l_EwsRequestOversized_Text = "_Ťhě řëqúëśţ ěxćęęďš ťhé 1 MB śîźę ĺîmîţ. Pĺëąśë móđífý ýőüŕ EWS ŕęqµëśţ.ȘȚșțĂîȘȚșțĂ_";
_u.ExtensibilityStrings.l_OffsetNotfound_Text = "_Äň öffšéť föŕ ťhíş ţîmę śţąmp čőúĺďň'ţ bë főµňď.ȘȚșțĂîȘ_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text = "_Ëĺěvăţëď pęřmíşšîôň íś řëqúîřěđ ťő čäľł ţhę męťhőď: '{0}'.ȘȚșțĂîȘȚș_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text = "_Ëĺěvăţëď pęřmíşšîôň íś řëqúîřěđ ťő ąčçéşš pŕöťěćţęď mëmbëŕş öf ťhę JăváŞçřîpţ API fóř Öffîčë.ȘȚșțĂîȘȚșțĂîȘȚ_";
_u.ExtensibilityStrings.l_InvalidEventDates_Text = "_Ťhě ěňđ ďąţě ôćçüŕś béföřë ţhě śťářť ďäťé.ȘȚșțĂî_";
_u.ExtensibilityStrings.l_InvalidDate_Text = "_Ťhě îňpúť ďôěşń'ţ řęśóĺvě ťô ą vąĺíď ďąťë.ȘȚșțĂî_";
_u.ExtensibilityStrings.l_InternalProtocolError_Text = "_Îňťëŕňąľ přôţôçôĺ éřřőŕ: '{0}'.ȘȚșțĂ_"
