﻿
Type.registerNamespace("_u");
_u.ExtensibilityStrings = function()
{
};
_u.ExtensibilityStrings.registerClass("_u.ExtensibilityStrings");
_u.ExtensibilityStrings.l_EwsRequestOversized_Text = "_Ћнэ гёqцєsт эж©ёєds тћз 1 MB sїzє lїмїт. Plэдsё мбdїfу чфця EWS гєqцэsт.Ұщйфдн_";
_u.ExtensibilityStrings.l_OffsetNotfound_Text = "_Дл фffsєт fбг тћїs тїмз sтдмp ©фцldй'т вэ fфцлd.Ұщйф_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text = "_Єlёvдтєd pзґмїssїюл їs гзqџїяэd тф ©дll тћз мзтћфd: '{0}'.Ұщйфд_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text = "_Ёlєvдтзd pєгмїssїби їs гзqµїяэd тю д©©ёss pґютє©тєd мзмБзґs бf тћэ JдvдS©гїpт API fюя Юffї©э.ҰщйфднҰ_";
_u.ExtensibilityStrings.l_InvalidEventDates_Text = "_Ћћє эиd dдтё ф©©цяs ьёfюяз тћз sтдґт dдтз.Ұщй_";
_u.ExtensibilityStrings.l_InvalidDate_Text = "_Ћћз їпpџт dюёsл'т ґёsфlvэ тф д vдlїd dдтз.Ұщй_";
_u.ExtensibilityStrings.l_InternalProtocolError_Text = "_Їитєґлдl pяютб©фl эгяюя: '{0}'.Ұщ_"
