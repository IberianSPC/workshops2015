Type.registerNamespace('_u');
_u.ExtensibilityStrings=function _u_ExtensibilityStrings() {
}
_u.ExtensibilityStrings.registerClass('_u.ExtensibilityStrings');
_u.ExtensibilityStrings.l_EwsRequestOversized_Text='The request exceeds the 1 MB size limit. Please modify your EWS request.';
_u.ExtensibilityStrings.l_OffsetNotfound_Text='An offset for this time stamp couldn\'t be found.';
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text='Elevated permission is required to call the method: \'{0}\'.';
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text='Elevated permission is required to access protected members of the JavaScript API for Office.';
_u.ExtensibilityStrings.l_InvalidEventDates_Text='The end date occurs before the start date.';
_u.ExtensibilityStrings.l_InvalidDate_Text='The input doesn\'t resolve to a valid date.';
_u.ExtensibilityStrings.l_InternalProtocolError_Text='Internal protocol error: \'{0}\'.';

