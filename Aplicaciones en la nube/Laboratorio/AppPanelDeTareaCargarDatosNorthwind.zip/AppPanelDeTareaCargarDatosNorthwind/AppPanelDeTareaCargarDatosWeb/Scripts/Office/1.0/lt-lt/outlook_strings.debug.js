﻿
Type.registerNamespace("_u");
_u.ExtensibilityStrings = function()
{
};
_u.ExtensibilityStrings.registerClass("_u.ExtensibilityStrings");
_u.ExtensibilityStrings.l_EwsRequestOversized_Text = "_Thē ŗęqųéšt ė×¢éėdś thė 1 MB §įżé ļįmįt. Płęæ§é mōdįfy yōüŗ EWS ŗéqµéšt.ąžčęįūšų_";
_u.ExtensibilityStrings.l_OffsetNotfound_Text = "_Äņ ōffšét f¤ŗ thį§ tīmė štąmp č¤ųłdņ't ßė fóüńd.ąžčęį_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text = "_Ēłévåtėd pēŗmįś§ī¤ņ įś ŗēqµįŗēd tõ ćāļł thē mēth°d: '{0}'.ąžčęįū_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text = "_Ęļėvåtēd pėŗmįś§įōņ īś ŗėqµįŗéd tø ą¢ćēšś pŗötēćtėd mēmßéŗś øf thė JævæŚćŗīpt API f¤ŗ Öffįćé.ąžčęįūšųėą_";
_u.ExtensibilityStrings.l_InvalidEventDates_Text = "_Thē ęņd dætē õ¢čųŗś ßęföŗė thė śtąŗt dåté.ąžčęį_";
_u.ExtensibilityStrings.l_InvalidDate_Text = "_Thé įńpüt d°ēšņ't ŗę§õłvē t¤ æ vąļįd däté.ąžčęį_";
_u.ExtensibilityStrings.l_InternalProtocolError_Text = "_Įńtéŗńæł pŗ°tó¢õł ęŗŗöŗ: '{0}'.ąžč_"
