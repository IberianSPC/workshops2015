﻿
Type.registerNamespace("_u");
_u.ExtensibilityStrings = function()
{
};
_u.ExtensibilityStrings.registerClass("_u.ExtensibilityStrings");
_u.ExtensibilityStrings.l_EwsRequestOversized_Text = "_Thε rεqύεsτ εxςέεds τhέ 1 MB sιzε lιmϊτ. Plεαsε mσdϊfy yόύr EWS rέqύεsτ.θλρωβθλρωβθλρωβθλρωβθλ_";
_u.ExtensibilityStrings.l_OffsetNotfound_Text = "_Λη όffsετ fφr τhιs τίmέ sταmp ςόϋldη'τ bε fσύηd.θλρωβθλρωβθλρω_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text = "_Σlενατεd pεrmιssϊσή ιs rεqϋϊrέd τό ςάll τhε mετhφd: '{0}'.θλρωβθλρωβθλρωβθλ_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text = "_Σlενατεd pεrmιssϊσή ιs rεqϋϊrέd τό αςςεss prότεςτεd mεmbέrs θf τhέ JαναSςrιpτ API fόr Θffϊςέ.θλρωβθλρωβθλρωβθλρωβθλρωβθλρ_";
_u.ExtensibilityStrings.l_InvalidEventDates_Text = "_Thε εηd dατε όςςϋrs bέfσrε τhε sταrτ dατε.θλρωβθλρωβθλρ_";
_u.ExtensibilityStrings.l_InvalidDate_Text = "_Thε ϊηpύτ dφεsή'τ rέsσlνε τό ά ναlϊd dάτε.θλρωβθλρωβθλρ_";
_u.ExtensibilityStrings.l_InternalProtocolError_Text = "_Ϊητεrήαl prότόςσl έrrφr: '{0}'.θλρωβθλρω_"
