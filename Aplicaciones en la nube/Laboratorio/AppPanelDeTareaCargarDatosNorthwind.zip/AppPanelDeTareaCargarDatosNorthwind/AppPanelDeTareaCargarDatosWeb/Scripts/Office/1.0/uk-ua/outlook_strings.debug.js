﻿
Type.registerNamespace("_u");
_u.ExtensibilityStrings = function()
{
};
_u.ExtensibilityStrings.registerClass("_u.ExtensibilityStrings");
_u.ExtensibilityStrings.l_EwsRequestOversized_Text = "_Ћћэ гзqцэsт эж©ёєds тћз 1 MB sїzэ lїмїт. Plэдsє мбdїfч уфцґ EWS яєqµзsт.ДЖлфюя_";
_u.ExtensibilityStrings.l_OffsetNotfound_Text = "_Дл бffsєт fюя тћїs тїмё sтдмp ©бџldл'т ъз fбцлd.ДЖлф_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text = "_Єlэvдтзd pєямїssїфй їs гэqџїяєd тб ©дll тћє мєтнфd: '{0}'.ДЖлфю_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text = "_Єlэvдтзd pєямїssїфй їs гэqџїяєd тб д©©єss pгбтє©тёd мэмъзгs юf тћє JдvдS©яїpт API fфґ Фffї©ё.ДЖлфюячД_";
_u.ExtensibilityStrings.l_InvalidEventDates_Text = "_Ћћэ єиd dдтё б©©цгs Бэfфяэ тнэ sтдґт dдтє.ДЖлф_";
_u.ExtensibilityStrings.l_InvalidDate_Text = "_Ћћэ їиpцт dюэsй'т гєsюlvэ тб д vдlїd dдтэ.ДЖлф_";
_u.ExtensibilityStrings.l_InternalProtocolError_Text = "_Їлтєґпдl pгбтф©юl ёяґбя: '{0}'.ДЖл_"
