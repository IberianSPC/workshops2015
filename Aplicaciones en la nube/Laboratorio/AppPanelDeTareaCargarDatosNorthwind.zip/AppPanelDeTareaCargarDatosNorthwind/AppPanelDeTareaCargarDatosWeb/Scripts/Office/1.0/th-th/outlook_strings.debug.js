﻿
Type.registerNamespace("_u");
_u.ExtensibilityStrings = function()
{
};
_u.ExtensibilityStrings.registerClass("_u.ExtensibilityStrings");
_u.ExtensibilityStrings.l_EwsRequestOversized_Text = "น้ำThe request exceeds the 1 MB size limit. Please modify your EWS request.ท้ายสุด";
_u.ExtensibilityStrings.l_OffsetNotfound_Text = "น้ำAn offset for this time stamp couldn't be found.ท้ายสุด";
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text = "น้ำElevated permission is required to call the method: '{0}'.ท้ายสุด";
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text = "น้ำElevated permission is required to access protected members of the JavaScript API for Office.ท้ายสุด";
_u.ExtensibilityStrings.l_InvalidEventDates_Text = "น้ำThe end date occurs before the start date.ท้ายสุด";
_u.ExtensibilityStrings.l_InvalidDate_Text = "น้ำThe input doesn't resolve to a valid date.ท้ายสุด";
_u.ExtensibilityStrings.l_InternalProtocolError_Text = "น้ำInternal protocol error: '{0}'.ท้ายสุด"
