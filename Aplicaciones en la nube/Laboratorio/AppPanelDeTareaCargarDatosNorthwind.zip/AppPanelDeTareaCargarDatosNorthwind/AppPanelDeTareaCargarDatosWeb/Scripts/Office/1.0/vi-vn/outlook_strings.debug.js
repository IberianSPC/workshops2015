﻿
Type.registerNamespace("_u");
_u.ExtensibilityStrings = function()
{
};
_u.ExtensibilityStrings.registerClass("_u.ExtensibilityStrings");
_u.ExtensibilityStrings.l_EwsRequestOversized_Text = "_Thè ®ëqûést ê×©ëé₫s thé 1 MB sîzê lïmít. Pléäsë m°đïƒÿ ÿóư® EWS ®êqúést.ệôụộị_";
_u.ExtensibilityStrings.l_OffsetNotfound_Text = "_Añ ¤ƒƒsét ƒö® thïs tîmê stämp çóµlđñ't bë ƒøúñđ.ệôụộ_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text = "_Ëlévătè₫ pè®mïssí°ñ ïs ®êqùí®ë₫ t¤ çăll thé méth¤đ: '{0}'.ệôụộ_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text = "_Élêvåtèđ pê®mïssí°ñ ís ®éqùï®ë₫ t° ă¢çêss p®ôtêçtêđ mèmbê®s óƒ thé Jàvá§©®ïpt API ƒơ® Ơƒƒî¢ê.ệôụộịế_";
_u.ExtensibilityStrings.l_InvalidEventDates_Text = "_Thè ëñ₫ đâtë ơç¢ú®s bëƒö®ê thè stá®t đătè.ệôụ_";
_u.ExtensibilityStrings.l_InvalidDate_Text = "_Thé ïñpùt ₫óésñ't ®ës¤lvé tö á vªlïđ ₫ætë.ệôụ_";
_u.ExtensibilityStrings.l_InternalProtocolError_Text = "_Ïñté®ñªl p®¤tœçœl é®®ö®: '{0}'.ệôụ_"
