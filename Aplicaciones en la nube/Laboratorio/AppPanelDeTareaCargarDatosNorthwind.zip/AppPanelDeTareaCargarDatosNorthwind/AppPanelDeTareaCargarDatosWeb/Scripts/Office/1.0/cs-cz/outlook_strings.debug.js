﻿
Type.registerNamespace("_u");
_u.ExtensibilityStrings = function()
{
};
_u.ExtensibilityStrings.registerClass("_u.ExtensibilityStrings");
_u.ExtensibilityStrings.l_EwsRequestOversized_Text = "_Ţhę řęqűëšţ ěxçëęďś ťhé 1 MB şîźě łîmîť. Pľéąşé mőđífý ýőűř EWS řëqüęşţ.ů§čřž_";
_u.ExtensibilityStrings.l_OffsetNotfound_Text = "_Ăň óffšęť fôř ťhíš ťímé śţámp ©óűłđń'ť bé fôµňđ.ů§č_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text = "_Ëľęváťéđ pěŕmîšśîőń íş řěqµíŕęđ ťó ćáľĺ ţhë měťhôđ: '{0}'.ů§čř_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text = "_Ęľëváţëđ pěŕmîśşîôń îš řěqüířęď ţó ăçčęşš přóţęćţëď měmběŕš ôf ţhě JävăŚčŕípť API fôř Ôffîčě.ů§čřžýů_";
_u.ExtensibilityStrings.l_InvalidEventDates_Text = "_Ţhě ëňđ đąţę őççµřš bëfőŕé ťhé šţáŕţ ďáťë.ů§č_";
_u.ExtensibilityStrings.l_InvalidDate_Text = "_Ţhě íńpüţ đőęśň'ţ ŕéśöłvě ťö â văłíď đăťé.ů§č_";
_u.ExtensibilityStrings.l_InternalProtocolError_Text = "_Îńţëŕňáĺ přôťôćöľ ěŕřôŕ: '{0}'.ů§_"
