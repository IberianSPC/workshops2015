﻿
Type.registerNamespace("_u");
_u.ExtensibilityStrings = function()
{
};
_u.ExtensibilityStrings.registerClass("_u.ExtensibilityStrings");
_u.ExtensibilityStrings.l_EwsRequestOversized_Text = "_Thè réqµést éx¢êéðs thé 1 MB sîzé lîmît. Plëªsé mõðïfý ÿøµr EWS réqùëst.aiya_";
_u.ExtensibilityStrings.l_OffsetNotfound_Text = "_Ãñ òffsêt fôr thïs tímê ståmp çõülðñ't þé fóµñð.aiy_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeededForMethod_Text = "_Êlévâtèð pèrmìssïóñ ís rëqüîrèð tò ¢æll thë mèthôð: '{0}'.aiy_";
_u.ExtensibilityStrings.l_ElevatedPermissionNeeded_Text = "_Élêvätèð pêrmíssïóñ îs rèqµírèð tõ æ¢¢éss pröté¢téð mêmþêrs ôf thè Jävã§çrípt API fòr Óffî¢ë.aiyaiy_";
_u.ExtensibilityStrings.l_InvalidEventDates_Text = "_Thè ëñð ðátë óç¢úrs þëfõré thê stärt ðàtë.aiy_";
_u.ExtensibilityStrings.l_InvalidDate_Text = "_Thé ïñpùt ðòésñ't résølvë tó â vàlïð ðåtë.aiy_";
_u.ExtensibilityStrings.l_InternalProtocolError_Text = "_Ïñtérñàl prøtò¢õl érrör: '{0}'.ai_"
