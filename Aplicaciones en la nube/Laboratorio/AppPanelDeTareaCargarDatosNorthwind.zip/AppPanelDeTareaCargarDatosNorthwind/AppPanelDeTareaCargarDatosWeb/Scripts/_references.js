﻿/// <reference path="jquery-1.8.2.js" />
/* Required to correctly initalize Office.js for intellisense */
/// <reference path="_officeintellisense.js" />
/* Use offline copy of Office.js for intellisense */
/// <reference path="office/1.0/office.js" />
/* Use online copy of Office.js for intellisense */
// /// <reference path="https://appsforoffice.microsoft.com/lib/1.0/hosted/outlook-15.debug.js" />
// /// <reference path="https://appsforoffice.microsoft.com/lib/1.0/hosted/office.js" />
