﻿/// <reference path="../App.js" />

    // La función de inicialización se debe ejecutar cada vez que se cargue una página nueva
    Office.initialize = function (reason) {
        $(document).ready(function () {
            app.initialize();
            ObtenerVentasCategoria();
        });
    };

    //Obtiene las ventas de la catetoria desde la base de datos
    function ObtenerVentasCategoria() {
        var lIdeCategoria = ObtenerIdCategoria();
        var lUrl = "http://services.odata.org/Northwind/Northwind.svc/Sales_by_Categories?$select=ProductName,ProductSales&$filter=CategoryID eq " + lIdeCategoria + "&$format=json&$callback=?"

        $.ajax({
            url: lUrl,
            contentType: 'application/json; charset=utf-8',
            dataType: 'jsonp',
            type: "GET",
            success: CargarVentasCategoriaSuccess,
            error: function (pRequest, pExito, pError) {
                PrintMessageNotification(pError, pExito);
            }
        });
    }

    //Carga la tabla de precios de la cartegoria
    function CargarVentasCategoriaSuccess(pDatos, pExito) {
        $(pDatos.value).each(function (clave, valor) {
            $('#vtaCategoria').find('tbody').append($('<tr><td>' + valor.ProductName + '</td><td>' + valor.ProductSales + '</td></tr>'));
        });
    }

    //Obtiene el id de la categoria almacenada en el documento
    function ObtenerIdCategoria() {
        return Office.context.document.settings.get("IdDeLaCategoria");
    }
    //Muestra un mensanje de error
    function PrintMessageNotification(pTitulo, pMsg) {
        app.showNotification(pTitulo, pMsg)
    }