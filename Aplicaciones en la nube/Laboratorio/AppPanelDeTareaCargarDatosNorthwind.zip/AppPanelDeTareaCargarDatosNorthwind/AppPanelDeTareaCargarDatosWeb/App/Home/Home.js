﻿/// <reference path="../App.js" />
/*global app*/

(function () {
    "use strict";

    var mIdCategoria = '';


    // La función de inicialización se debe ejecutar cada vez que se cargue una página nueva
    Office.initialize = function (reason) {
        $(document).ready(function () {
            app.initialize();
            $('#get-data-productos-categoria').click(getDataProductosCategoriesNorthwind);
            $('#slCategorias').change(getIdCategorySelected);
            getCategoriasNorthwind();
        });
    };


    //Carga las categorias desde el servicio REST
    function getCategoriasNorthwind() {

        $.ajax({
            url: "http://services.odata.org/Northwind/Northwind.svc/Categories?$select=CategoryID,CategoryName&$format=json&$callback=?",
            contentType: 'application/json; charset=utf-8',
            dataType: 'jsonp',
            type: "GET",
            success: getCategoriesNorthwindSucess,
            error: function (pRequest, pExito, pError) {
                PrintMessageNotification(pError, pExito);
            }
        });
    }

    //Procesa los datos que son recibidos de la consulta REST
    function getCategoriesNorthwindSucess(pDatos, pExito) {
        PrintMessageNotification("Cartegorias", pExito);

        $(pDatos.value).each(function (clave, valor) {
            $('#slCategorias')
            .append($('<option>', { value: valor.CategoryID })
            .text(valor.CategoryName));
        });
    }

    //obtiene los productos de la categoria seleccionada y los carga en el Excel
    function getDataProductosCategoriesNorthwind() {
        $('#notification-message').hide();

        getIdCategorySelected();

        var lUrl = "http://services.odata.org/Northwind/Northwind.svc/Products?$select=ProductID,ProductName,UnitPrice&$filter=CategoryID eq " + mIdCategoria + "&$format=json&$callback=?"

        $.ajax({
            url: lUrl,
            contentType: 'application/json; charset=utf-8',
            dataType: 'jsonp',
            type: "GET",
            success: SetProductosDocumentoExcelSuccess,
            error: function (pRequest, pExito, pError) {
                PrintMessageNotification(pError, pExito);
            }
        });
    }

    function SetProductosDocumentoExcelSuccess(pDatos, pExito) {

        var lTabla = new Office.TableData();
        lTabla.headers = ["Id Prodcuto", "Nombre Producto", "Precio"];
        var lRows = new Array();
        lRows = ArmarFilasTabla(pDatos.value);
        lTabla.rows = lRows;

        // se persite la categoría que el usuario selecciono
        GuardarIdCategoria(mIdCategoria);

        Office.context.document.bindings.getByIdAsync("Productos", function (pResultado) {
            if (pResultado.status == Office.AsyncResultStatus.Succeeded) {
                //borrar las filas e insertar las filas
                pResultado.value.deleteAllDataValuesAsync();
                //se cargan los datos nuevos traidos por el servicio              
                pResultado.value.addRowsAsync(lRows, function (pResultado) {
                    if (pResultado.status == Office.AsyncResultStatus.Succeeded) {
                        PrintMessageNotification("Productos sincronizados", pResultado.status);
                    }
                    else {
                        PrintMessageNotification("Productos sincronizados", pResultado.status);
                    }
                });
            }
            else {
                Office.context.document.setSelectedDataAsync(lTabla, function (pResultado) {
                    if (pResultado.status == Office.AsyncResultStatus.Succeeded) {
                        Office.context.document.bindings.addFromSelectionAsync(Office.BindingType.Table, { id: "Productos" }, function (pResultado) {
                            if (pResultado.status == Office.AsyncResultStatus.Succeeded) {
                                PrintMessageNotification("Productos agregados", pResultado.status);
                            }
                            else {
                                PrintMessageNotification("Productos no agregados", pResultado.status);
                            }
                        });
                    }
                    else {
                        //no se puedo agregar la tabla.
                        PrintMessageNotification("Error: " + pResultado.error.name, pResultado.error.message);
                    }
                });
            }
        });
    }

    //se arma la tabla a partir de los datos recibidos del servicio
    function ArmarFilasTabla(pDatos) {
        var lRows = new Array();
        $.each(pDatos, function (pIndice, pValor) {
            lRows[pIndice] = [pValor.ProductID, pValor.ProductName, pValor.UnitPrice];
        });
        return lRows;
    }

    //Guardar la categoría seleccionada por el usuario
    function GuardarIdCategoria(pIdCategoria) {
        Office.context.document.settings.set("IdDeLaCategoria", mIdCategoria);
        Office.context.document.settings.saveAsync();
    }

    //Obtiene el Id de la categoría seleccionada.
    function getIdCategorySelected() {
        var lIdCatAux = $("#slCategorias").val();
        if ($.isNumeric(lIdCatAux)) {
            mIdCategoria = lIdCatAux;
        }
        else {
            mIdCategoria = null;
        }
    }

    //Muestra un mensanje de error
    function PrintMessageNotification(pTitulo, pMsg) {
        app.showNotification(pTitulo, pMsg);
    }
})();