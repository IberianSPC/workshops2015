﻿/// <reference path="../App.js" />
/*global app*/

(function () {
    "use strict";

    var mIdCategoria = '';
    var mNombreCategoria = '';

    // La función de inicialización se debe ejecutar cada vez que se cargue una página nueva
    Office.initialize = function (reason) {
        $(document).ready(function () {
            app.initialize();
            $('#get-data-productos-categoria').click(getDataProductosCategoriesSharePoint);
            $('#slCategorias').change(getIdCategorySelected);
            getCategoriasSharePoint();
        });
    };


    //Carga las categorias desde el servicio REST
    function getCategoriasSharePoint() {

        $.ajax({
            url: "http://spdev/_api/web/lists/GetByTitle('Categories')/items?$select=Id,Title",
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: getCategoriesSharePointSucess,
            error: function (pRequest, pExito, pError) {
                PrintMessageNotification(pError, pExito);
            }
        });
    }

    //Procesa los datos que son recibidos de la consulta REST
    function getCategoriesSharePointSucess(pDatos, pExito) {
        PrintMessageNotification("Cartegorias", pExito);

        $(pDatos.d.results).each(function (clave, valor) {
            $('#slCategorias')
            .append($('<option>', { value: valor.Id })
            .text(valor.Title));
        });
    }

    //obtiene los productos de la categoria seleccionada y los carga en el Excel
    function getDataProductosCategoriesSharePoint() {
        $('#notification-message').hide();

        getIdCategorySelected();

        var lUrl = "http://spdev/_api/web/lists/GetByTitle('Products')/items?$select=Id,Title,UnitPrice&$filter=Category eq '"+ mNombreCategoria + "'";

        $.ajax({
            url: lUrl,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: SetProductosDocumentoExcelSuccess,
            error: function (pRequest, pExito, pError) {
                PrintMessageNotification(pError, pExito);
            }
        });
    }

    function SetProductosDocumentoExcelSuccess(pDatos, pExito) {

        var lTabla = new Office.TableData();
        lTabla.headers = ["Id Prodcuto", "Nombre Producto", "Precio"];
        var lRows = new Array();
        lRows = ArmarFilasTabla(pDatos.d.results);
        lTabla.rows = lRows;

        Office.context.document.bindings.getByIdAsync("Productos", function (pResultado) {
            if (pResultado.status == Office.AsyncResultStatus.Succeeded) {
                //borrar las filas e insertar las filas
                pResultado.value.deleteAllDataValuesAsync();
                //se cargan los datos nuevos traidos por el servicio              
                pResultado.value.addRowsAsync(lRows, function (pResultado) {
                    if (pResultado.status == Office.AsyncResultStatus.Succeeded) {
                        PrintMessageNotification("Productos sincronizados", pResultado.status);
                    }
                    else {
                        PrintMessageNotification("Productos sincronizados", pResultado.status);
                    }
                });
            }
            else {
                Office.context.document.setSelectedDataAsync(lTabla, function (pResultado) {
                    if (pResultado.status == Office.AsyncResultStatus.Succeeded) {
                        Office.context.document.bindings.addFromSelectionAsync(Office.BindingType.Table, { id: "Productos" }, function (pResultado) {
                            if (pResultado.status == Office.AsyncResultStatus.Succeeded) {
                                PrintMessageNotification("Productos agregados", pResultado.status);
                            }
                            else {
                                PrintMessageNotification("Productos no agregados", pResultado.status);
                            }
                        });
                    }
                    else {
                        //no se puedo agregar la tabla.
                        PrintMessageNotification("Error: " + pResultado.error.name, pResultado.error.message);
                    }
                });
            }
        });
    }

    //se arma la tabla a partir de los datos recibidos del servicio
    function ArmarFilasTabla(pDatos) {
        var lRows = new Array();
        $.each(pDatos, function (pIndice, pValor) {
            lRows[pIndice] = [pValor.Id, pValor.Title, pValor.UnitPrice];
        });
        return lRows;
    }

    //Guardar la categoría seleccionada por el usuario
    function GuardarIdCategoria(pIdCategoria, pNombreCategoria) {
        Office.context.document.settings.set("IdDeLaCategoria", pIdCategoria);
        Office.context.document.settings.set("NombreCategoria", pNombreCategoria);
        Office.context.document.settings.saveAsync();
    }


    //Obtiene el Id de la categoría seleccionada.
    function getIdCategorySelected() {
        var lIdCatAux = $("#slCategorias").val();
        if ($.isNumeric(lIdCatAux)) {
            mIdCategoria = lIdCatAux;
            mNombreCategoria = $("#slCategorias :selected").text();
            GuardarIdCategoria(mIdCategoria, mNombreCategoria);
        }
        else {
            mIdCategoria = null;
            mNombreCategoria = null;
        }
    }

    //Muestra un mensanje de error
    function PrintMessageNotification(pTitulo, pMsg) {
        app.showNotification(pTitulo, pMsg);
    }
})();