﻿/// <reference path="../App.js" />
(function () {
    "use strict";

    var mIdCategoria = '';
    var mNombreCategoria = '';
    var mRows = new Array();

    // La función de inicialización se debe ejecutar cada vez que se cargue una página nueva
    Office.initialize = function (reason) {
        $(document).ready(function () {
            app.initialize();
            $('#chart').click(AgregarGrafica);
            $('#divGraficaMain').hide();
            ObtenerCategoriaSeleccionada();
            ObtenerVentasCategoria();

        });
    };

    //Obtiene las ventas de la catetoria desde la base de datos
    function ObtenerVentasCategoria() {

        var lUrl = "http://spdev/_api/web/lists/GetByTitle('Sales by Categories')/items?$select=Id,Title,ProductSales&$filter=Category eq '" + mNombreCategoria +"'"

        $.ajax({
            url: lUrl,
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: CargarVentasCategoriaSuccess,
            error: function (pRequest, pExito, pError) {
                PrintMessageNotification(pError, pExito);
            }
        });
    }

    //Carga la tabla de precios de la cartegoria
    function CargarVentasCategoriaSuccess(pDatos, pExito) {
        mRows = ArmarFilasTabla(pDatos.d.results)
        $(pDatos.d.results).each(function (clave, valor) {
            $('#vtaCategoria').find('tbody').append($('<tr><td>' + valor.Title + '</td><td>' + valor.ProductSales + '</td></tr>'));
        });
    }

    function AgregarGrafica() {
        if ($('#chart').text() == "Grafica") {
            $('#tblVentas').hide();
            $('#divGraficaMain').show();
            $('#chart').text("Tabla");
            var myChart = new JSChart('Grafica', 'pie');
            myChart.setDataArray(mRows);

            myChart.draw();
        }
        else
        {
            $('#tblVentas').show();
            $('#divGraficaMain').hide();
            $('#chart').text("Grafica");
        }
    }

    //se arma la tabla a partir de los datos recibidos del servicio
    function ArmarFilasTabla(pDatos) {
        var lRows = new Array();
        $.each(pDatos, function (pIndice, pValor) {
            lRows[pIndice] = [pValor.Title, pValor.ProductSales];
        });
        return lRows;
    }

    //Obtiene el id de la categoria almacenada en el documento
    function ObtenerCategoriaSeleccionada() {
        mIdCategoria = Office.context.document.settings.get("IdDeLaCategoria");
        mNombreCategoria = Office.context.document.settings.get("NombreCategoria");
    }
    //Muestra un mensanje de error
    function PrintMessageNotification(pTitulo, pMsg) {
        app.showNotification(pTitulo, pMsg)
    }
})();