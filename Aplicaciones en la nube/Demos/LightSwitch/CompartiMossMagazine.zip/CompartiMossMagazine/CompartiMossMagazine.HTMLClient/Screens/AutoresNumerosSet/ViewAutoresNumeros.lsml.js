﻿/// <reference path="~/GeneratedArtifacts/viewModel.js" />

myapp.ViewAutoresNumeros.Details_postRender = function (element, contentItem) {
    // Write code here.
    var name = contentItem.screen.AutoresNumeros.details.getModel()[':@SummaryProperty'].property.name;
    contentItem.dataBind("screen.AutoresNumeros." + name, function (value) {
        contentItem.screen.details.displayName = value;
    });
}

