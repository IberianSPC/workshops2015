﻿/// <reference path="../Scripts/msls.js" />

window.myapp = msls.application;

(function (lightSwitchApplication) {

    var $Entity = msls.Entity,
        $DataService = msls.DataService,
        $DataWorkspace = msls.DataWorkspace,
        $defineEntity = msls._defineEntity,
        $defineDataService = msls._defineDataService,
        $defineDataWorkspace = msls._defineDataWorkspace,
        $DataServiceQuery = msls.DataServiceQuery,
        $toODataString = msls._toODataString;

    function Autores(entitySet) {
        /// <summary>
        /// Represents the Autores entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this autores.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this autores.
        /// </field>
        /// <field name="Nombre" type="String">
        /// Gets or sets the nombre for this autores.
        /// </field>
        /// <field name="Apellido" type="String">
        /// Gets or sets the apellido for this autores.
        /// </field>
        /// <field name="Correo" type="String">
        /// Gets or sets the correo for this autores.
        /// </field>
        /// <field name="Twitter" type="String">
        /// Gets or sets the twitter for this autores.
        /// </field>
        /// <field name="Foto" type="String">
        /// Gets or sets the foto for this autores.
        /// </field>
        /// <field name="AutoresNumerosCollection" type="msls.EntityCollection" elementType="msls.application.AutoresNumeros">
        /// Gets the autoresNumerosCollection for this autores.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this autores.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this autores.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this autores.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this autores.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this autores.
        /// </field>
        /// <field name="details" type="msls.application.Autores.Details">
        /// Gets the details for this autores.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function Numeros(entitySet) {
        /// <summary>
        /// Represents the Numeros entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this numeros.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this numeros.
        /// </field>
        /// <field name="Nro" type="String">
        /// Gets or sets the nro for this numeros.
        /// </field>
        /// <field name="Anio" type="String">
        /// Gets or sets the anio for this numeros.
        /// </field>
        /// <field name="Imagen" type="String">
        /// Gets or sets the imagen for this numeros.
        /// </field>
        /// <field name="Url" type="String">
        /// Gets or sets the url for this numeros.
        /// </field>
        /// <field name="AutoresNumerosCollection" type="msls.EntityCollection" elementType="msls.application.AutoresNumeros">
        /// Gets the autoresNumerosCollection for this numeros.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this numeros.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this numeros.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this numeros.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this numeros.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this numeros.
        /// </field>
        /// <field name="details" type="msls.application.Numeros.Details">
        /// Gets the details for this numeros.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function AutoresNumeros(entitySet) {
        /// <summary>
        /// Represents the AutoresNumeros entity type.
        /// </summary>
        /// <param name="entitySet" type="msls.EntitySet" optional="true">
        /// The entity set that should contain this autoresNumeros.
        /// </param>
        /// <field name="Id" type="Number">
        /// Gets or sets the id for this autoresNumeros.
        /// </field>
        /// <field name="Autores" type="msls.application.Autores">
        /// Gets or sets the autores for this autoresNumeros.
        /// </field>
        /// <field name="Numeros" type="msls.application.Numeros">
        /// Gets or sets the numeros for this autoresNumeros.
        /// </field>
        /// <field name="CreatedBy" type="String">
        /// Gets or sets the createdBy for this autoresNumeros.
        /// </field>
        /// <field name="Created" type="Date">
        /// Gets or sets the created for this autoresNumeros.
        /// </field>
        /// <field name="ModifiedBy" type="String">
        /// Gets or sets the modifiedBy for this autoresNumeros.
        /// </field>
        /// <field name="Modified" type="Date">
        /// Gets or sets the modified for this autoresNumeros.
        /// </field>
        /// <field name="RowVersion" type="Array">
        /// Gets or sets the rowVersion for this autoresNumeros.
        /// </field>
        /// <field name="details" type="msls.application.AutoresNumeros.Details">
        /// Gets the details for this autoresNumeros.
        /// </field>
        $Entity.call(this, entitySet);
    }

    function ApplicationData(dataWorkspace) {
        /// <summary>
        /// Represents the ApplicationData data service.
        /// </summary>
        /// <param name="dataWorkspace" type="msls.DataWorkspace">
        /// The data workspace that created this data service.
        /// </param>
        /// <field name="AutoresSet" type="msls.EntitySet">
        /// Gets the AutoresSet entity set.
        /// </field>
        /// <field name="NumerosSet" type="msls.EntitySet">
        /// Gets the NumerosSet entity set.
        /// </field>
        /// <field name="AutoresNumerosSet" type="msls.EntitySet">
        /// Gets the AutoresNumerosSet entity set.
        /// </field>
        /// <field name="details" type="msls.application.ApplicationData.Details">
        /// Gets the details for this data service.
        /// </field>
        $DataService.call(this, dataWorkspace);
    };
    function DataWorkspace() {
        /// <summary>
        /// Represents the data workspace.
        /// </summary>
        /// <field name="ApplicationData" type="msls.application.ApplicationData">
        /// Gets the ApplicationData data service.
        /// </field>
        /// <field name="details" type="msls.application.DataWorkspace.Details">
        /// Gets the details for this data workspace.
        /// </field>
        $DataWorkspace.call(this);
    };

    msls._addToNamespace("msls.application", {

        Autores: $defineEntity(Autores, [
            { name: "Id", type: Number },
            { name: "Nombre", type: String },
            { name: "Apellido", type: String },
            { name: "Correo", type: String },
            { name: "Twitter", type: String },
            { name: "Foto", type: String },
            { name: "AutoresNumerosCollection", kind: "collection", elementType: AutoresNumeros },
            { name: "CreatedBy", type: String, isReadOnly: true },
            { name: "Created", type: Date, isReadOnly: true },
            { name: "ModifiedBy", type: String, isReadOnly: true },
            { name: "Modified", type: Date, isReadOnly: true },
            { name: "RowVersion", type: Array }
        ]),

        Numeros: $defineEntity(Numeros, [
            { name: "Id", type: Number },
            { name: "Nro", type: String },
            { name: "Anio", type: String },
            { name: "Imagen", type: String },
            { name: "Url", type: String },
            { name: "AutoresNumerosCollection", kind: "collection", elementType: AutoresNumeros },
            { name: "CreatedBy", type: String, isReadOnly: true },
            { name: "Created", type: Date, isReadOnly: true },
            { name: "ModifiedBy", type: String, isReadOnly: true },
            { name: "Modified", type: Date, isReadOnly: true },
            { name: "RowVersion", type: Array }
        ]),

        AutoresNumeros: $defineEntity(AutoresNumeros, [
            { name: "Id", type: Number },
            { name: "Autores", kind: "reference", type: Autores },
            { name: "Numeros", kind: "reference", type: Numeros },
            { name: "CreatedBy", type: String, isReadOnly: true },
            { name: "Created", type: Date, isReadOnly: true },
            { name: "ModifiedBy", type: String, isReadOnly: true },
            { name: "Modified", type: Date, isReadOnly: true },
            { name: "RowVersion", type: Array }
        ]),

        ApplicationData: $defineDataService(ApplicationData, lightSwitchApplication.rootUri + "/ApplicationData.svc", [
            { name: "AutoresSet", elementType: Autores },
            { name: "NumerosSet", elementType: Numeros },
            { name: "AutoresNumerosSet", elementType: AutoresNumeros }
        ], [
            {
                name: "AutoresSet_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.AutoresSet },
                        lightSwitchApplication.rootUri + "/ApplicationData.svc" + "/AutoresSet(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "NumerosSet_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.NumerosSet },
                        lightSwitchApplication.rootUri + "/ApplicationData.svc" + "/NumerosSet(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            },
            {
                name: "AutoresNumerosSet_SingleOrDefault", value: function (Id) {
                    return new $DataServiceQuery({ _entitySet: this.AutoresNumerosSet },
                        lightSwitchApplication.rootUri + "/ApplicationData.svc" + "/AutoresNumerosSet(" + "Id=" + $toODataString(Id, "Int32?") + ")"
                    );
                }
            }
        ]),

        DataWorkspace: $defineDataWorkspace(DataWorkspace, [
            { name: "ApplicationData", type: ApplicationData }
        ])

    });

}(msls.application));
