﻿/// <reference path="data.js" />

(function (lightSwitchApplication) {

    var $Screen = msls.Screen,
        $defineScreen = msls._defineScreen,
        $DataServiceQuery = msls.DataServiceQuery,
        $toODataString = msls._toODataString,
        $defineShowScreen = msls._defineShowScreen;

    function AddEditAutoresNumeros(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditAutoresNumeros screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="AutoresNumeros" type="msls.application.AutoresNumeros">
        /// Gets or sets the autoresNumeros for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditAutoresNumeros.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditAutoresNumeros", parameters);
    }

    function BrowseAutoresNumerosSet(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the BrowseAutoresNumerosSet screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="AutoresNumerosSet" type="msls.VisualCollection" elementType="msls.application.AutoresNumeros">
        /// Gets the autoresNumerosSet for this screen.
        /// </field>
        /// <field name="details" type="msls.application.BrowseAutoresNumerosSet.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "BrowseAutoresNumerosSet", parameters);
    }

    function ViewAutoresNumeros(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the ViewAutoresNumeros screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="AutoresNumeros" type="msls.application.AutoresNumeros">
        /// Gets or sets the autoresNumeros for this screen.
        /// </field>
        /// <field name="details" type="msls.application.ViewAutoresNumeros.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "ViewAutoresNumeros", parameters);
    }

    function AddEditAutoresRevista(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditAutoresRevista screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Autores" type="msls.application.Autores">
        /// Gets or sets the autores for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditAutoresRevista.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditAutoresRevista", parameters);
    }

    function BrowseAutoresRevistas(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the BrowseAutoresRevistas screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="AutoresSet" type="msls.VisualCollection" elementType="msls.application.Autores">
        /// Gets the autoresSet for this screen.
        /// </field>
        /// <field name="details" type="msls.application.BrowseAutoresRevistas.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "BrowseAutoresRevistas", parameters);
    }

    function ViewAutoresRevista(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the ViewAutoresRevista screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Autores" type="msls.application.Autores">
        /// Gets or sets the autores for this screen.
        /// </field>
        /// <field name="details" type="msls.application.ViewAutoresRevista.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "ViewAutoresRevista", parameters);
    }

    function Compartimos(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the Compartimos screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="details" type="msls.application.Compartimos.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "Compartimos", parameters);
    }

    function AddEditNumerosRevista(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the AddEditNumerosRevista screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Numeros" type="msls.application.Numeros">
        /// Gets or sets the numeros for this screen.
        /// </field>
        /// <field name="details" type="msls.application.AddEditNumerosRevista.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "AddEditNumerosRevista", parameters);
    }

    function BrowseNumerosRevistas(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the BrowseNumerosRevistas screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="NumerosSet" type="msls.VisualCollection" elementType="msls.application.Numeros">
        /// Gets the numerosSet for this screen.
        /// </field>
        /// <field name="details" type="msls.application.BrowseNumerosRevistas.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "BrowseNumerosRevistas", parameters);
    }

    function ViewNumerosRevista(parameters, dataWorkspace) {
        /// <summary>
        /// Represents the ViewNumerosRevista screen.
        /// </summary>
        /// <param name="parameters" type="Array">
        /// An array of screen parameter values.
        /// </param>
        /// <param name="dataWorkspace" type="msls.application.DataWorkspace" optional="true">
        /// An existing data workspace for this screen to use. By default, a new data workspace is created.
        /// </param>
        /// <field name="Numeros" type="msls.application.Numeros">
        /// Gets or sets the numeros for this screen.
        /// </field>
        /// <field name="details" type="msls.application.ViewNumerosRevista.Details">
        /// Gets the details for this screen.
        /// </field>
        if (!dataWorkspace) {
            dataWorkspace = new lightSwitchApplication.DataWorkspace();
        }
        $Screen.call(this, dataWorkspace, "ViewNumerosRevista", parameters);
    }

    msls._addToNamespace("msls.application", {

        AddEditAutoresNumeros: $defineScreen(AddEditAutoresNumeros, [
            { name: "AutoresNumeros", kind: "local", type: lightSwitchApplication.AutoresNumeros }
        ], [
        ]),

        BrowseAutoresNumerosSet: $defineScreen(BrowseAutoresNumerosSet, [
            {
                name: "AutoresNumerosSet", kind: "collection", elementType: lightSwitchApplication.AutoresNumeros,
                createQuery: function () {
                    return this.dataWorkspace.ApplicationData.AutoresNumerosSet.expand("Autores").expand("Numeros");
                }
            }
        ], [
        ]),

        ViewAutoresNumeros: $defineScreen(ViewAutoresNumeros, [
            { name: "AutoresNumeros", kind: "local", type: lightSwitchApplication.AutoresNumeros }
        ], [
        ]),

        AddEditAutoresRevista: $defineScreen(AddEditAutoresRevista, [
            { name: "Autores", kind: "local", type: lightSwitchApplication.Autores }
        ], [
        ]),

        BrowseAutoresRevistas: $defineScreen(BrowseAutoresRevistas, [
            {
                name: "AutoresSet", kind: "collection", elementType: lightSwitchApplication.Autores,
                createQuery: function () {
                    return this.dataWorkspace.ApplicationData.AutoresSet;
                }
            }
        ], [
        ]),

        ViewAutoresRevista: $defineScreen(ViewAutoresRevista, [
            { name: "Autores", kind: "local", type: lightSwitchApplication.Autores }
        ], [
        ]),

        Compartimos: $defineScreen(Compartimos, [
        ], [
        ]),

        AddEditNumerosRevista: $defineScreen(AddEditNumerosRevista, [
            { name: "Numeros", kind: "local", type: lightSwitchApplication.Numeros }
        ], [
        ]),

        BrowseNumerosRevistas: $defineScreen(BrowseNumerosRevistas, [
            {
                name: "NumerosSet", kind: "collection", elementType: lightSwitchApplication.Numeros,
                createQuery: function () {
                    return this.dataWorkspace.ApplicationData.NumerosSet;
                }
            }
        ], [
        ]),

        ViewNumerosRevista: $defineScreen(ViewNumerosRevista, [
            { name: "Numeros", kind: "local", type: lightSwitchApplication.Numeros }
        ], [
        ]),

        showAddEditAutoresNumeros: $defineShowScreen(function showAddEditAutoresNumeros(AutoresNumeros, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditAutoresNumeros screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditAutoresNumeros", parameters, options);
        }),

        showBrowseAutoresNumerosSet: $defineShowScreen(function showBrowseAutoresNumerosSet(options) {
            /// <summary>
            /// Asynchronously navigates forward to the BrowseAutoresNumerosSet screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 0);
            return lightSwitchApplication.showScreen("BrowseAutoresNumerosSet", parameters, options);
        }),

        showViewAutoresNumeros: $defineShowScreen(function showViewAutoresNumeros(AutoresNumeros, options) {
            /// <summary>
            /// Asynchronously navigates forward to the ViewAutoresNumeros screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("ViewAutoresNumeros", parameters, options);
        }),

        showAddEditAutoresRevista: $defineShowScreen(function showAddEditAutoresRevista(Autores, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditAutoresRevista screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditAutoresRevista", parameters, options);
        }),

        showBrowseAutoresRevistas: $defineShowScreen(function showBrowseAutoresRevistas(options) {
            /// <summary>
            /// Asynchronously navigates forward to the BrowseAutoresRevistas screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 0);
            return lightSwitchApplication.showScreen("BrowseAutoresRevistas", parameters, options);
        }),

        showViewAutoresRevista: $defineShowScreen(function showViewAutoresRevista(Autores, options) {
            /// <summary>
            /// Asynchronously navigates forward to the ViewAutoresRevista screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("ViewAutoresRevista", parameters, options);
        }),

        showCompartimos: $defineShowScreen(function showCompartimos(options) {
            /// <summary>
            /// Asynchronously navigates forward to the Compartimos screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 0);
            return lightSwitchApplication.showScreen("Compartimos", parameters, options);
        }),

        showAddEditNumerosRevista: $defineShowScreen(function showAddEditNumerosRevista(Numeros, options) {
            /// <summary>
            /// Asynchronously navigates forward to the AddEditNumerosRevista screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("AddEditNumerosRevista", parameters, options);
        }),

        showBrowseNumerosRevistas: $defineShowScreen(function showBrowseNumerosRevistas(options) {
            /// <summary>
            /// Asynchronously navigates forward to the BrowseNumerosRevistas screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 0);
            return lightSwitchApplication.showScreen("BrowseNumerosRevistas", parameters, options);
        }),

        showViewNumerosRevista: $defineShowScreen(function showViewNumerosRevista(Numeros, options) {
            /// <summary>
            /// Asynchronously navigates forward to the ViewNumerosRevista screen.
            /// </summary>
            /// <param name="options" optional="true">
            /// An object that provides one or more of the following options:<br/>- beforeShown: a function that is called after boundary behavior has been applied but before the screen is shown.<br/>+ Signature: beforeShown(screen)<br/>- afterClosed: a function that is called after boundary behavior has been applied and the screen has been closed.<br/>+ Signature: afterClosed(screen, action : msls.NavigateBackAction)
            /// </param>
            /// <returns type="WinJS.Promise" />
            var parameters = Array.prototype.slice.call(arguments, 0, 1);
            return lightSwitchApplication.showScreen("ViewNumerosRevista", parameters, options);
        })

    });

}(msls.application));
