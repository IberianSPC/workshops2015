﻿/// <reference path="data.js" />

(function (lightSwitchApplication) {

    msls._addEntryPoints(lightSwitchApplication.Autores, {
        /// <field>
        /// Called when a new autores is created.
        /// <br/>created(msls.application.Autores entity)
        /// </field>
        created: [lightSwitchApplication.Autores]
    });

    msls._addEntryPoints(lightSwitchApplication.Numeros, {
        /// <field>
        /// Called when a new numeros is created.
        /// <br/>created(msls.application.Numeros entity)
        /// </field>
        created: [lightSwitchApplication.Numeros]
    });

    msls._addEntryPoints(lightSwitchApplication.AutoresNumeros, {
        /// <field>
        /// Called when a new autoresNumeros is created.
        /// <br/>created(msls.application.AutoresNumeros entity)
        /// </field>
        created: [lightSwitchApplication.AutoresNumeros]
    });

}(msls.application));
