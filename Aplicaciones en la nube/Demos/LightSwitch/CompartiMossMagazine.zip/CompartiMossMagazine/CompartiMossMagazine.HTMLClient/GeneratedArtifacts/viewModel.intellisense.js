﻿/// <reference path="viewModel.js" />

(function (lightSwitchApplication) {

    var $element = document.createElement("div");

    lightSwitchApplication.AddEditAutoresNumeros.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditAutoresNumeros
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditAutoresNumeros,
            data: lightSwitchApplication.AddEditAutoresNumeros,
            value: lightSwitchApplication.AddEditAutoresNumeros
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditAutoresNumeros,
            data: lightSwitchApplication.AddEditAutoresNumeros,
            value: lightSwitchApplication.AutoresNumeros
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.AutoresNumeros
        },
        Autores: {
            _$class: msls.ContentItem,
            _$name: "Autores",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.Autores
        },
        RowTemplate: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate",
            _$parentName: "Autores",
            screen: lightSwitchApplication.AddEditAutoresNumeros,
            data: lightSwitchApplication.Autores,
            value: lightSwitchApplication.Autores
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.AutoresNumeros
        },
        Numeros: {
            _$class: msls.ContentItem,
            _$name: "Numeros",
            _$parentName: "right",
            screen: lightSwitchApplication.AddEditAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.Numeros
        },
        RowTemplate1: {
            _$class: msls.ContentItem,
            _$name: "RowTemplate1",
            _$parentName: "Numeros",
            screen: lightSwitchApplication.AddEditAutoresNumeros,
            data: lightSwitchApplication.Numeros,
            value: lightSwitchApplication.Numeros
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditAutoresNumeros
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditAutoresNumeros, {
        /// <field>
        /// Called when a new AddEditAutoresNumeros screen is created.
        /// <br/>created(msls.application.AddEditAutoresNumeros screen)
        /// </field>
        created: [lightSwitchApplication.AddEditAutoresNumeros],
        /// <field>
        /// Called before changes on an active AddEditAutoresNumeros screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditAutoresNumeros screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditAutoresNumeros],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresNumeros().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresNumeros().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresNumeros().findContentItem("left"); }],
        /// <field>
        /// Called after the Autores content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Autores_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresNumeros().findContentItem("Autores"); }],
        /// <field>
        /// Called after the RowTemplate content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresNumeros().findContentItem("RowTemplate"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresNumeros().findContentItem("right"); }],
        /// <field>
        /// Called after the Numeros content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Numeros_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresNumeros().findContentItem("Numeros"); }],
        /// <field>
        /// Called after the RowTemplate1 content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        RowTemplate1_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresNumeros().findContentItem("RowTemplate1"); }]
    });

    lightSwitchApplication.BrowseAutoresNumerosSet.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseAutoresNumerosSet
        },
        AutoresNumerosList: {
            _$class: msls.ContentItem,
            _$name: "AutoresNumerosList",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseAutoresNumerosSet,
            data: lightSwitchApplication.BrowseAutoresNumerosSet,
            value: lightSwitchApplication.BrowseAutoresNumerosSet
        },
        AutoresNumerosSet: {
            _$class: msls.ContentItem,
            _$name: "AutoresNumerosSet",
            _$parentName: "AutoresNumerosList",
            screen: lightSwitchApplication.BrowseAutoresNumerosSet,
            data: lightSwitchApplication.BrowseAutoresNumerosSet,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseAutoresNumerosSet,
                _$entry: {
                    elementType: lightSwitchApplication.AutoresNumeros
                }
            }
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "AutoresNumerosSet",
            screen: lightSwitchApplication.BrowseAutoresNumerosSet,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.AutoresNumeros
        },
        Id: {
            _$class: msls.ContentItem,
            _$name: "Id",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseAutoresNumerosSet,
            data: lightSwitchApplication.AutoresNumeros,
            value: Number
        },
        Autores: {
            _$class: msls.ContentItem,
            _$name: "Autores",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseAutoresNumerosSet,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.Autores
        },
        Numeros: {
            _$class: msls.ContentItem,
            _$name: "Numeros",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseAutoresNumerosSet,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.Numeros
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseAutoresNumerosSet
        }
    };

    msls._addEntryPoints(lightSwitchApplication.BrowseAutoresNumerosSet, {
        /// <field>
        /// Called when a new BrowseAutoresNumerosSet screen is created.
        /// <br/>created(msls.application.BrowseAutoresNumerosSet screen)
        /// </field>
        created: [lightSwitchApplication.BrowseAutoresNumerosSet],
        /// <field>
        /// Called before changes on an active BrowseAutoresNumerosSet screen are applied.
        /// <br/>beforeApplyChanges(msls.application.BrowseAutoresNumerosSet screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.BrowseAutoresNumerosSet],
        /// <field>
        /// Called after the AutoresNumerosList content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        AutoresNumerosList_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresNumerosSet().findContentItem("AutoresNumerosList"); }],
        /// <field>
        /// Called after the AutoresNumerosSet content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        AutoresNumerosSet_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresNumerosSet().findContentItem("AutoresNumerosSet"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresNumerosSet().findContentItem("rows"); }],
        /// <field>
        /// Called after the Id content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Id_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresNumerosSet().findContentItem("Id"); }],
        /// <field>
        /// Called after the Autores content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Autores_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresNumerosSet().findContentItem("Autores"); }],
        /// <field>
        /// Called after the Numeros content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Numeros_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresNumerosSet().findContentItem("Numeros"); }]
    });

    lightSwitchApplication.ViewAutoresNumeros.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewAutoresNumeros
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewAutoresNumeros,
            data: lightSwitchApplication.ViewAutoresNumeros,
            value: lightSwitchApplication.ViewAutoresNumeros
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.ViewAutoresNumeros,
            data: lightSwitchApplication.ViewAutoresNumeros,
            value: lightSwitchApplication.AutoresNumeros
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.ViewAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.AutoresNumeros
        },
        Autores: {
            _$class: msls.ContentItem,
            _$name: "Autores",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.Autores
        },
        Numeros: {
            _$class: msls.ContentItem,
            _$name: "Numeros",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.Numeros
        },
        CreatedBy: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.ViewAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: lightSwitchApplication.AutoresNumeros
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: Date
        },
        ModifiedBy: {
            _$class: msls.ContentItem,
            _$name: "ModifiedBy",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: String
        },
        Modified: {
            _$class: msls.ContentItem,
            _$name: "Modified",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewAutoresNumeros,
            data: lightSwitchApplication.AutoresNumeros,
            value: Date
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewAutoresNumeros
        }
    };

    msls._addEntryPoints(lightSwitchApplication.ViewAutoresNumeros, {
        /// <field>
        /// Called when a new ViewAutoresNumeros screen is created.
        /// <br/>created(msls.application.ViewAutoresNumeros screen)
        /// </field>
        created: [lightSwitchApplication.ViewAutoresNumeros],
        /// <field>
        /// Called before changes on an active ViewAutoresNumeros screen are applied.
        /// <br/>beforeApplyChanges(msls.application.ViewAutoresNumeros screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.ViewAutoresNumeros],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresNumeros().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresNumeros().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresNumeros().findContentItem("left"); }],
        /// <field>
        /// Called after the Autores content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Autores_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresNumeros().findContentItem("Autores"); }],
        /// <field>
        /// Called after the Numeros content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Numeros_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresNumeros().findContentItem("Numeros"); }],
        /// <field>
        /// Called after the CreatedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresNumeros().findContentItem("CreatedBy"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresNumeros().findContentItem("right"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresNumeros().findContentItem("Created"); }],
        /// <field>
        /// Called after the ModifiedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ModifiedBy_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresNumeros().findContentItem("ModifiedBy"); }],
        /// <field>
        /// Called after the Modified content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Modified_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresNumeros().findContentItem("Modified"); }]
    });

    lightSwitchApplication.AddEditAutoresRevista.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditAutoresRevista
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditAutoresRevista,
            data: lightSwitchApplication.AddEditAutoresRevista,
            value: lightSwitchApplication.AddEditAutoresRevista
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditAutoresRevista,
            data: lightSwitchApplication.AddEditAutoresRevista,
            value: lightSwitchApplication.Autores
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: lightSwitchApplication.Autores
        },
        Nombre: {
            _$class: msls.ContentItem,
            _$name: "Nombre",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Apellido: {
            _$class: msls.ContentItem,
            _$name: "Apellido",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Correo: {
            _$class: msls.ContentItem,
            _$name: "Correo",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: lightSwitchApplication.Autores
        },
        Twitter: {
            _$class: msls.ContentItem,
            _$name: "Twitter",
            _$parentName: "right",
            screen: lightSwitchApplication.AddEditAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Foto: {
            _$class: msls.ContentItem,
            _$name: "Foto",
            _$parentName: "right",
            screen: lightSwitchApplication.AddEditAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditAutoresRevista
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditAutoresRevista, {
        /// <field>
        /// Called when a new AddEditAutoresRevista screen is created.
        /// <br/>created(msls.application.AddEditAutoresRevista screen)
        /// </field>
        created: [lightSwitchApplication.AddEditAutoresRevista],
        /// <field>
        /// Called before changes on an active AddEditAutoresRevista screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditAutoresRevista screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditAutoresRevista],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresRevista().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresRevista().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresRevista().findContentItem("left"); }],
        /// <field>
        /// Called after the Nombre content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Nombre_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresRevista().findContentItem("Nombre"); }],
        /// <field>
        /// Called after the Apellido content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Apellido_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresRevista().findContentItem("Apellido"); }],
        /// <field>
        /// Called after the Correo content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Correo_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresRevista().findContentItem("Correo"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresRevista().findContentItem("right"); }],
        /// <field>
        /// Called after the Twitter content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Twitter_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresRevista().findContentItem("Twitter"); }],
        /// <field>
        /// Called after the Foto content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Foto_postRender: [$element, function () { return new lightSwitchApplication.AddEditAutoresRevista().findContentItem("Foto"); }]
    });

    lightSwitchApplication.BrowseAutoresRevistas.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseAutoresRevistas
        },
        AutoresRevistaList: {
            _$class: msls.ContentItem,
            _$name: "AutoresRevistaList",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseAutoresRevistas,
            data: lightSwitchApplication.BrowseAutoresRevistas,
            value: lightSwitchApplication.BrowseAutoresRevistas
        },
        AutoresSet: {
            _$class: msls.ContentItem,
            _$name: "AutoresSet",
            _$parentName: "AutoresRevistaList",
            screen: lightSwitchApplication.BrowseAutoresRevistas,
            data: lightSwitchApplication.BrowseAutoresRevistas,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseAutoresRevistas,
                _$entry: {
                    elementType: lightSwitchApplication.Autores
                }
            }
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "AutoresSet",
            screen: lightSwitchApplication.BrowseAutoresRevistas,
            data: lightSwitchApplication.Autores,
            value: lightSwitchApplication.Autores
        },
        Foto: {
            _$class: msls.ContentItem,
            _$name: "Foto",
            _$parentName: "columns",
            screen: lightSwitchApplication.BrowseAutoresRevistas,
            data: lightSwitchApplication.Autores,
            value: String
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "columns",
            screen: lightSwitchApplication.BrowseAutoresRevistas,
            data: lightSwitchApplication.Autores,
            value: lightSwitchApplication.Autores
        },
        Nombre: {
            _$class: msls.ContentItem,
            _$name: "Nombre",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseAutoresRevistas,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Apellido: {
            _$class: msls.ContentItem,
            _$name: "Apellido",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseAutoresRevistas,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Correo: {
            _$class: msls.ContentItem,
            _$name: "Correo",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseAutoresRevistas,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseAutoresRevistas
        }
    };

    msls._addEntryPoints(lightSwitchApplication.BrowseAutoresRevistas, {
        /// <field>
        /// Called when a new BrowseAutoresRevistas screen is created.
        /// <br/>created(msls.application.BrowseAutoresRevistas screen)
        /// </field>
        created: [lightSwitchApplication.BrowseAutoresRevistas],
        /// <field>
        /// Called before changes on an active BrowseAutoresRevistas screen are applied.
        /// <br/>beforeApplyChanges(msls.application.BrowseAutoresRevistas screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.BrowseAutoresRevistas],
        /// <field>
        /// Called after the AutoresRevistaList content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        AutoresRevistaList_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresRevistas().findContentItem("AutoresRevistaList"); }],
        /// <field>
        /// Called after the AutoresSet content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        AutoresSet_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresRevistas().findContentItem("AutoresSet"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresRevistas().findContentItem("columns"); }],
        /// <field>
        /// Called after the Foto content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Foto_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresRevistas().findContentItem("Foto"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresRevistas().findContentItem("rows"); }],
        /// <field>
        /// Called after the Nombre content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Nombre_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresRevistas().findContentItem("Nombre"); }],
        /// <field>
        /// Called after the Apellido content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Apellido_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresRevistas().findContentItem("Apellido"); }],
        /// <field>
        /// Called after the Correo content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Correo_postRender: [$element, function () { return new lightSwitchApplication.BrowseAutoresRevistas().findContentItem("Correo"); }]
    });

    lightSwitchApplication.ViewAutoresRevista.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewAutoresRevista
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.ViewAutoresRevista,
            value: lightSwitchApplication.ViewAutoresRevista
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.ViewAutoresRevista,
            value: lightSwitchApplication.Autores
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: lightSwitchApplication.Autores
        },
        Nombre: {
            _$class: msls.ContentItem,
            _$name: "Nombre",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Apellido: {
            _$class: msls.ContentItem,
            _$name: "Apellido",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Correo: {
            _$class: msls.ContentItem,
            _$name: "Correo",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Twitter: {
            _$class: msls.ContentItem,
            _$name: "Twitter",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Foto: {
            _$class: msls.ContentItem,
            _$name: "Foto",
            _$parentName: "left",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: lightSwitchApplication.Autores
        },
        CreatedBy: {
            _$class: msls.ContentItem,
            _$name: "CreatedBy",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Created: {
            _$class: msls.ContentItem,
            _$name: "Created",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: Date
        },
        ModifiedBy: {
            _$class: msls.ContentItem,
            _$name: "ModifiedBy",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: String
        },
        Modified: {
            _$class: msls.ContentItem,
            _$name: "Modified",
            _$parentName: "right",
            screen: lightSwitchApplication.ViewAutoresRevista,
            data: lightSwitchApplication.Autores,
            value: Date
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewAutoresRevista
        }
    };

    msls._addEntryPoints(lightSwitchApplication.ViewAutoresRevista, {
        /// <field>
        /// Called when a new ViewAutoresRevista screen is created.
        /// <br/>created(msls.application.ViewAutoresRevista screen)
        /// </field>
        created: [lightSwitchApplication.ViewAutoresRevista],
        /// <field>
        /// Called before changes on an active ViewAutoresRevista screen are applied.
        /// <br/>beforeApplyChanges(msls.application.ViewAutoresRevista screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.ViewAutoresRevista],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("left"); }],
        /// <field>
        /// Called after the Nombre content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Nombre_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("Nombre"); }],
        /// <field>
        /// Called after the Apellido content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Apellido_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("Apellido"); }],
        /// <field>
        /// Called after the Correo content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Correo_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("Correo"); }],
        /// <field>
        /// Called after the Twitter content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Twitter_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("Twitter"); }],
        /// <field>
        /// Called after the Foto content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Foto_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("Foto"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("right"); }],
        /// <field>
        /// Called after the CreatedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        CreatedBy_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("CreatedBy"); }],
        /// <field>
        /// Called after the Created content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Created_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("Created"); }],
        /// <field>
        /// Called after the ModifiedBy content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        ModifiedBy_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("ModifiedBy"); }],
        /// <field>
        /// Called after the Modified content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Modified_postRender: [$element, function () { return new lightSwitchApplication.ViewAutoresRevista().findContentItem("Modified"); }]
    });

    lightSwitchApplication.Compartimos.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.Compartimos
        },
        Group: {
            _$class: msls.ContentItem,
            _$name: "Group",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.Compartimos,
            data: lightSwitchApplication.Compartimos,
            value: lightSwitchApplication.Compartimos
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.Compartimos
        }
    };

    msls._addEntryPoints(lightSwitchApplication.Compartimos, {
        /// <field>
        /// Called when a new Compartimos screen is created.
        /// <br/>created(msls.application.Compartimos screen)
        /// </field>
        created: [lightSwitchApplication.Compartimos],
        /// <field>
        /// Called before changes on an active Compartimos screen are applied.
        /// <br/>beforeApplyChanges(msls.application.Compartimos screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.Compartimos],
        /// <field>
        /// Called after the Group content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Group_postRender: [$element, function () { return new lightSwitchApplication.Compartimos().findContentItem("Group"); }]
    });

    lightSwitchApplication.AddEditNumerosRevista.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditNumerosRevista
        },
        Details: {
            _$class: msls.ContentItem,
            _$name: "Details",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.AddEditNumerosRevista,
            data: lightSwitchApplication.AddEditNumerosRevista,
            value: lightSwitchApplication.AddEditNumerosRevista
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "Details",
            screen: lightSwitchApplication.AddEditNumerosRevista,
            data: lightSwitchApplication.AddEditNumerosRevista,
            value: lightSwitchApplication.Numeros
        },
        left: {
            _$class: msls.ContentItem,
            _$name: "left",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditNumerosRevista,
            data: lightSwitchApplication.Numeros,
            value: lightSwitchApplication.Numeros
        },
        Nro: {
            _$class: msls.ContentItem,
            _$name: "Nro",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditNumerosRevista,
            data: lightSwitchApplication.Numeros,
            value: String
        },
        Anio: {
            _$class: msls.ContentItem,
            _$name: "Anio",
            _$parentName: "left",
            screen: lightSwitchApplication.AddEditNumerosRevista,
            data: lightSwitchApplication.Numeros,
            value: String
        },
        right: {
            _$class: msls.ContentItem,
            _$name: "right",
            _$parentName: "columns",
            screen: lightSwitchApplication.AddEditNumerosRevista,
            data: lightSwitchApplication.Numeros,
            value: lightSwitchApplication.Numeros
        },
        Imagen: {
            _$class: msls.ContentItem,
            _$name: "Imagen",
            _$parentName: "right",
            screen: lightSwitchApplication.AddEditNumerosRevista,
            data: lightSwitchApplication.Numeros,
            value: String
        },
        Url: {
            _$class: msls.ContentItem,
            _$name: "Url",
            _$parentName: "right",
            screen: lightSwitchApplication.AddEditNumerosRevista,
            data: lightSwitchApplication.Numeros,
            value: String
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.AddEditNumerosRevista
        }
    };

    msls._addEntryPoints(lightSwitchApplication.AddEditNumerosRevista, {
        /// <field>
        /// Called when a new AddEditNumerosRevista screen is created.
        /// <br/>created(msls.application.AddEditNumerosRevista screen)
        /// </field>
        created: [lightSwitchApplication.AddEditNumerosRevista],
        /// <field>
        /// Called before changes on an active AddEditNumerosRevista screen are applied.
        /// <br/>beforeApplyChanges(msls.application.AddEditNumerosRevista screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.AddEditNumerosRevista],
        /// <field>
        /// Called after the Details content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Details_postRender: [$element, function () { return new lightSwitchApplication.AddEditNumerosRevista().findContentItem("Details"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.AddEditNumerosRevista().findContentItem("columns"); }],
        /// <field>
        /// Called after the left content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        left_postRender: [$element, function () { return new lightSwitchApplication.AddEditNumerosRevista().findContentItem("left"); }],
        /// <field>
        /// Called after the Nro content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Nro_postRender: [$element, function () { return new lightSwitchApplication.AddEditNumerosRevista().findContentItem("Nro"); }],
        /// <field>
        /// Called after the Anio content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Anio_postRender: [$element, function () { return new lightSwitchApplication.AddEditNumerosRevista().findContentItem("Anio"); }],
        /// <field>
        /// Called after the right content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        right_postRender: [$element, function () { return new lightSwitchApplication.AddEditNumerosRevista().findContentItem("right"); }],
        /// <field>
        /// Called after the Imagen content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Imagen_postRender: [$element, function () { return new lightSwitchApplication.AddEditNumerosRevista().findContentItem("Imagen"); }],
        /// <field>
        /// Called after the Url content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Url_postRender: [$element, function () { return new lightSwitchApplication.AddEditNumerosRevista().findContentItem("Url"); }]
    });

    lightSwitchApplication.BrowseNumerosRevistas.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseNumerosRevistas
        },
        NumerosRevistaList: {
            _$class: msls.ContentItem,
            _$name: "NumerosRevistaList",
            _$parentName: "Tabs",
            screen: lightSwitchApplication.BrowseNumerosRevistas,
            data: lightSwitchApplication.BrowseNumerosRevistas,
            value: lightSwitchApplication.BrowseNumerosRevistas
        },
        NumerosSet: {
            _$class: msls.ContentItem,
            _$name: "NumerosSet",
            _$parentName: "NumerosRevistaList",
            screen: lightSwitchApplication.BrowseNumerosRevistas,
            data: lightSwitchApplication.BrowseNumerosRevistas,
            value: {
                _$class: msls.VisualCollection,
                screen: lightSwitchApplication.BrowseNumerosRevistas,
                _$entry: {
                    elementType: lightSwitchApplication.Numeros
                }
            }
        },
        columns: {
            _$class: msls.ContentItem,
            _$name: "columns",
            _$parentName: "NumerosSet",
            screen: lightSwitchApplication.BrowseNumerosRevistas,
            data: lightSwitchApplication.Numeros,
            value: lightSwitchApplication.Numeros
        },
        Imagen: {
            _$class: msls.ContentItem,
            _$name: "Imagen",
            _$parentName: "columns",
            screen: lightSwitchApplication.BrowseNumerosRevistas,
            data: lightSwitchApplication.Numeros,
            value: String
        },
        rows: {
            _$class: msls.ContentItem,
            _$name: "rows",
            _$parentName: "columns",
            screen: lightSwitchApplication.BrowseNumerosRevistas,
            data: lightSwitchApplication.Numeros,
            value: lightSwitchApplication.Numeros
        },
        Nro: {
            _$class: msls.ContentItem,
            _$name: "Nro",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseNumerosRevistas,
            data: lightSwitchApplication.Numeros,
            value: String
        },
        Anio: {
            _$class: msls.ContentItem,
            _$name: "Anio",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseNumerosRevistas,
            data: lightSwitchApplication.Numeros,
            value: String
        },
        Url: {
            _$class: msls.ContentItem,
            _$name: "Url",
            _$parentName: "rows",
            screen: lightSwitchApplication.BrowseNumerosRevistas,
            data: lightSwitchApplication.Numeros,
            value: String
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.BrowseNumerosRevistas
        }
    };

    msls._addEntryPoints(lightSwitchApplication.BrowseNumerosRevistas, {
        /// <field>
        /// Called when a new BrowseNumerosRevistas screen is created.
        /// <br/>created(msls.application.BrowseNumerosRevistas screen)
        /// </field>
        created: [lightSwitchApplication.BrowseNumerosRevistas],
        /// <field>
        /// Called before changes on an active BrowseNumerosRevistas screen are applied.
        /// <br/>beforeApplyChanges(msls.application.BrowseNumerosRevistas screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.BrowseNumerosRevistas],
        /// <field>
        /// Called after the NumerosRevistaList content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        NumerosRevistaList_postRender: [$element, function () { return new lightSwitchApplication.BrowseNumerosRevistas().findContentItem("NumerosRevistaList"); }],
        /// <field>
        /// Called after the NumerosSet content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        NumerosSet_postRender: [$element, function () { return new lightSwitchApplication.BrowseNumerosRevistas().findContentItem("NumerosSet"); }],
        /// <field>
        /// Called after the columns content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        columns_postRender: [$element, function () { return new lightSwitchApplication.BrowseNumerosRevistas().findContentItem("columns"); }],
        /// <field>
        /// Called after the Imagen content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Imagen_postRender: [$element, function () { return new lightSwitchApplication.BrowseNumerosRevistas().findContentItem("Imagen"); }],
        /// <field>
        /// Called after the rows content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        rows_postRender: [$element, function () { return new lightSwitchApplication.BrowseNumerosRevistas().findContentItem("rows"); }],
        /// <field>
        /// Called after the Nro content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Nro_postRender: [$element, function () { return new lightSwitchApplication.BrowseNumerosRevistas().findContentItem("Nro"); }],
        /// <field>
        /// Called after the Anio content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Anio_postRender: [$element, function () { return new lightSwitchApplication.BrowseNumerosRevistas().findContentItem("Anio"); }],
        /// <field>
        /// Called after the Url content item has been rendered.
        /// <br/>postRender(HTMLElement element, msls.ContentItem contentItem)
        /// </field>
        Url_postRender: [$element, function () { return new lightSwitchApplication.BrowseNumerosRevistas().findContentItem("Url"); }]
    });

    lightSwitchApplication.ViewNumerosRevista.prototype._$contentItems = {
        Tabs: {
            _$class: msls.ContentItem,
            _$name: "Tabs",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewNumerosRevista
        },
        Popups: {
            _$class: msls.ContentItem,
            _$name: "Popups",
            _$parentName: "RootContentItem",
            screen: lightSwitchApplication.ViewNumerosRevista
        }
    };

    msls._addEntryPoints(lightSwitchApplication.ViewNumerosRevista, {
        /// <field>
        /// Called when a new ViewNumerosRevista screen is created.
        /// <br/>created(msls.application.ViewNumerosRevista screen)
        /// </field>
        created: [lightSwitchApplication.ViewNumerosRevista],
        /// <field>
        /// Called before changes on an active ViewNumerosRevista screen are applied.
        /// <br/>beforeApplyChanges(msls.application.ViewNumerosRevista screen)
        /// </field>
        beforeApplyChanges: [lightSwitchApplication.ViewNumerosRevista]
    });

}(msls.application));